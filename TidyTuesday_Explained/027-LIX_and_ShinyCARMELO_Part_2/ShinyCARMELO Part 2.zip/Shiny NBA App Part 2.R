
## Data
# https://www.kaggle.com/drgilermo/nba-players-stats?select=Seasons_Stats.csv

## Inspiration
# https://projects.fivethirtyeight.com/carmelo/

## Packages -------------------------------------------------------------------
library(tidyverse)
library(shiny)
library(patchwork)
library(ggpubr)
library(here)
library(ggtext)

theme_set(theme_bw() +
            theme(axis.text = element_text(size = 12, face = "bold"),
                  axis.title = element_text(size = 16),
                  panel.border = element_blank(),
                  panel.grid.major = element_line(color = "grey")))

percentile <- function(x){
  a = (rank(x, ties.method = "average") / length(x)) * 100
  a
}

## Data ----------------------------------------------------------------------

stats <- read.csv(here("TidyTuesday_Explained/027/Seasons_Stats.csv"), header = TRUE ) %>%
  filter(Year > 2009) %>%
  select(-X) %>%
  group_by(Player, Year) %>%
  summarize(
    Positions = paste(unique(Pos), collapse = "/"),
    Teams = paste(unique(Tm), collapse = "/"),
    across(c("G", "MP", "FG", "FGA", "X3P", "X3PA", "X2P", "X2PA", "FT", "FTA", "ORB", "DRB", "TRB", "AST", "STL", "BLK", "TOV", "VORP"), sum, na.rm = T))

vitals <- read.csv(here("TidyTuesday_Explained/027/Players.csv"), header = TRUE) %>%
  select(-X)

## Data Prep ----------------------------------------------------------------

nba_stats <- stats %>%
  filter(between(Year, left = 2015, right = 2017)) %>%
  group_by(Player) %>%
  summarize(across(c("G", "MP", "FGA", "FG", "X3PA", "X3P", "FTA", "FT", "TRB", "AST", "STL", "BLK"), ~sum(.x))) %>%
  filter(MP >= 1000) %>%
  mutate(MPG = MP/G,
         FG_Pct = FG / FGA,
         Three_Pct = X3P / X3PA,
         FT_Pct = FT / FTA,
         TRB_48 = TRB / MP * 48,
         AST_48 = AST / MP * 48,
         STL_48 = STL / MP * 48,
         BLK_48 = BLK /  MP * 48,
         across(c("MPG":"BLK_48"), list(pctl = percentile))
         ) %>% 
  ungroup()

head(nba_stats)

## Helper Functions ----------------------------------------------------------
source(here("TidyTuesday_Explained/027/helper_funcs.R"))


#### Shiny App -----------------------------------------------------------------------
## ui

ui <- fluidPage(
  
  sidebarPanel(
    width = 3,
    
    selectInput(inputId = "Player",
                label = "Player",
                choices = unique(nba_stats$Player),
                selected = "LeBron James")
    
  ),
  
  mainPanel(
        plotOutput(outputId = "plt_score"),
        plotOutput(outputId = "plt_def")
  )
)


server <- function(input, output){

  
  player_stats <- reactive({
    
    nba_stats %>%
      filter(Player == input$Player)
    
  })
  
  
  scoring_stats <- reactive({
    
    player_stats() %>%
      rename(
        FG_Pct_value = FG_Pct,
        FT_Pct_value = FT_Pct,
        Three_Pct_value = Three_Pct,
        AST_48_value = AST_48
      ) %>%
      table_summarized_values(
        FG_Pct_value,
        FT_Pct_value,
        Three_Pct_value,
        AST_48_value,
        FG_Pct_pctl,
        FT_Pct_pctl,
        Three_Pct_pctl,
        AST_48_pctl
      ) %>% 
      mutate(
        value = case_when(
          stat == "AST_48" ~ as.character(round(value,1)),
          TRUE ~  scales::percent(value)
          ),
        stat = case_when(
          stat == "Three_Pct" ~ "3PT%",
          stat == "FT_Pct" ~ "FT%",
          stat == "FG_Pct" ~ "FG%",
          stat == "AST_48" ~ "AST/48"
        ),
        stat = factor(stat, rev(unique(stat))),
        color = case_when(pctl > 75 ~ "Good",
                          pctl < 45 ~ "Bad",
                          TRUE ~ "Average"),
        color = factor(color, levels = c("Bad","Average","Good"))
      )
        
  })
  
  
  defense_stats <- reactive({
    
    player_stats() %>%
      rename(
        TRB_48_value = TRB_48,
        BLK_48_value = BLK_48,
        STL_48_value = STL_48,
      ) %>% 
      table_summarized_values(
        TRB_48_value,
        BLK_48_value,
        STL_48_value,
        TRB_48_pctl,
        BLK_48_pctl, 
        STL_48_pctl) %>%
      mutate(
        value = round(value,1),
        stat = case_when(
          stat == "TRB_48" ~ "TRB/48",
          stat == "BLK_48" ~ "BLK/48",
          TRUE ~ "STL/48"),
        stat = factor(stat, rev(unique(stat))),
        color = case_when(pctl > 75 ~ "Good",
                          pctl < 45 ~ "Bad",
                          TRUE ~ "Average"),
        color = factor(color, levels = c("Bad","Average","Good"))
      )
    
  })
  
  output$plt_score <- renderPlot({
    scoring_stats()  %>% 
      table_point_plots("Scoring")
  })
  
  output$plt_def <- renderPlot({
    defense_stats() %>% 
      table_point_plots("Defense")
  })
  
}


shinyApp(ui, server)
